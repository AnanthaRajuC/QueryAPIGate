--
-- PostgreSQL database dump
--

\restrict brfxd938lGZflnNsrSBDZP0wE7qDODQOjzh4nUqN3LUvVSoffSbR8parioGl6wK

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: qag_fixture; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA qag_fixture;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.api_keys (
    name text NOT NULL COLLATE pg_catalog."C",
    hash text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_log (
    id bigint NOT NULL,
    rowid bigint GENERATED ALWAYS AS (id) STORED,
    "timestamp" text NOT NULL,
    entry_json text NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.audit_log_id_seq OWNED BY qag_fixture.audit_log.id;


--
-- Name: connections; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.connections (
    name text NOT NULL COLLATE pg_catalog."C",
    db text NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: execution_history; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.execution_history (
    rowid bigint NOT NULL,
    query_name text COLLATE pg_catalog."C",
    version integer,
    executed_at text NOT NULL,
    entry_json text NOT NULL,
    status text,
    key_name text
);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.execution_history_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.execution_history_rowid_seq OWNED BY qag_fixture.execution_history.rowid;


--
-- Name: roles; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.roles (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: saved_queries; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_queries (
    name text NOT NULL COLLATE pg_catalog."C",
    collection text COLLATE pg_catalog."C",
    example integer DEFAULT 0 NOT NULL,
    published_version integer
);


--
-- Name: saved_query_versions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_query_versions (
    query_name text NOT NULL COLLATE pg_catalog."C",
    version integer NOT NULL,
    uuid text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text NOT NULL,
    last_modified_at text NOT NULL,
    fields_json text NOT NULL
);


--
-- Name: schema_version; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.schema_version (
    version integer NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log ALTER COLUMN id SET DEFAULT nextval('qag_fixture.audit_log_id_seq'::regclass);


--
-- Name: execution_history rowid; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history ALTER COLUMN rowid SET DEFAULT nextval('qag_fixture.execution_history_rowid_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.api_keys VALUES ('reporting', 'f99a6c7817d7bbebe9b7e93be105ee33b742374cc4e1638905eab04777971ded', 1, NULL, '2026-10-04 16:12:23', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "created_from_role": null}');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.audit_log VALUES (1, DEFAULT, '2026-10-04 16:12:23', '{"timestamp": "2026-10-04 16:12:23", "actor": "admin", "action": "create_connection", "target": "films", "changes": {"database": "/tmp/qag-fixture-0.13.0-ckhuo3fb/data.db", "db": "sqlite", "active": true, "created_at": "2026-10-04 16:12:23", "updated_at": "2026-10-04 16:12:23"}}');
INSERT INTO qag_fixture.audit_log VALUES (2, DEFAULT, '2026-10-04 16:12:23', '{"timestamp": "2026-10-04 16:12:23", "actor": "admin", "action": "save_query", "target": "films_by_rating", "changes": {"version": 1, "connection_name": "films", "published": true}}');
INSERT INTO qag_fixture.audit_log VALUES (3, DEFAULT, '2026-10-04 16:12:23', '{"timestamp": "2026-10-04 16:12:23", "actor": "admin", "action": "save_query", "target": "films_by_rating", "changes": {"version": 2, "connection_name": "films", "published": true}}');
INSERT INTO qag_fixture.audit_log VALUES (4, DEFAULT, '2026-10-04 16:12:23', '{"timestamp": "2026-10-04 16:12:23", "actor": "admin", "action": "create_key", "target": "reporting", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "created_from_role": null, "active": true, "expires_at": null, "created_at": "2026-10-04 16:12:23"}}');
INSERT INTO qag_fixture.audit_log VALUES (5, DEFAULT, '2026-10-04 16:12:23', '{"timestamp": "2026-10-04 16:12:23", "actor": "admin", "action": "create_role", "target": "analyst", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "created_at": "2026-10-04 16:12:23"}}');


--
-- Data for Name: connections; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.connections VALUES ('films', 'sqlite', 1, '2026-10-04 16:12:23', '2026-10-04 16:12:23', '{"database": "/tmp/qag-fixture-0.13.0-ckhuo3fb/data.db"}');


--
-- Data for Name: execution_history; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.execution_history VALUES (1, 'films_by_rating', 2, '2026-10-04 16:12:23', '{"executed_at": "2026-10-04 16:12:23", "connection_name": "films", "request_id": "42b7fe351ab8", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 1, "serialization_ms": 0.1}', 'success', 'admin');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.roles VALUES ('analyst', '2026-10-04 16:12:23', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null}');


--
-- Data for Name: saved_queries; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_queries VALUES ('films_by_rating', NULL, 0, 2);


--
-- Data for Name: saved_query_versions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 1, 'a964d58e-8148-453e-a1ec-0078399fe3d6', 'active', '2026-10-04 16:12:23', '2026-10-04 16:12:23', '{"author": "fixture", "description": "Films by rating", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating"}');
INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 2, 'f06d8063-8f76-4884-99b7-1f9b5a94b575', 'active', '2026-10-04 16:12:23', '2026-10-04 16:12:23', '{"author": "fixture", "description": "Films by rating, sorted", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating ORDER BY title"}');


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.schema_version VALUES (5);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.audit_log_id_seq', 5, true);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.execution_history_rowid_seq', 1, true);


--
-- Name: api_keys api_keys_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_hash_key UNIQUE (hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (name);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (name);


--
-- Name: execution_history execution_history_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_pkey PRIMARY KEY (rowid);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (name);


--
-- Name: saved_queries saved_queries_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_queries
    ADD CONSTRAINT saved_queries_pkey PRIMARY KEY (name);


--
-- Name: saved_query_versions saved_query_versions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_pkey PRIMARY KEY (query_name, version);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_audit_log_timestamp ON qag_fixture.audit_log USING btree ("timestamp");


--
-- Name: idx_execution_history_qv; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_qv ON qag_fixture.execution_history USING btree (query_name, version, executed_at);


--
-- Name: idx_execution_history_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_time ON qag_fixture.execution_history USING btree (executed_at);


--
-- Name: execution_history execution_history_query_name_version_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_query_name_version_fkey FOREIGN KEY (query_name, version) REFERENCES qag_fixture.saved_query_versions(query_name, version) ON DELETE CASCADE;


--
-- Name: saved_query_versions saved_query_versions_query_name_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_query_name_fkey FOREIGN KEY (query_name) REFERENCES qag_fixture.saved_queries(name) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict brfxd938lGZflnNsrSBDZP0wE7qDODQOjzh4nUqN3LUvVSoffSbR8parioGl6wK

