--
-- PostgreSQL database dump
--

\restrict lsQ84PVIVgougVsdx8PslV3VHijR84a3closVKKfG9cmLavXj1zN65Szp9XTo7d

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: qag_fixture; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA qag_fixture;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_sessions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_sessions (
    id_hash text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    csrf text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    details_json text NOT NULL
);


--
-- Name: admin_tokens; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_tokens (
    id text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    hash text NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: administrators; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.administrators (
    name text NOT NULL COLLATE pg_catalog."C",
    role text,
    active integer DEFAULT 1 NOT NULL,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.api_keys (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    hash text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL,
    previous_hash text,
    previous_expires_at text
);


--
-- Name: audit_chain; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_chain (
    name text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    hash text NOT NULL
);


--
-- Name: audit_delivery; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_delivery (
    output text NOT NULL COLLATE pg_catalog."C",
    last_seq bigint DEFAULT 0 NOT NULL,
    lease_until double precision,
    details_json text DEFAULT '{}'::text NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_log (
    id bigint NOT NULL,
    rowid bigint GENERATED ALWAYS AS (id) STORED,
    "timestamp" text NOT NULL,
    entry_json text NOT NULL,
    seq bigint,
    prev_hash text,
    hash text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.audit_log_id_seq OWNED BY qag_fixture.audit_log.id;


--
-- Name: config_applied; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.config_applied (
    file_hash text NOT NULL COLLATE pg_catalog."C",
    applied_at text NOT NULL,
    actor text NOT NULL
);


--
-- Name: config_managed; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.config_managed (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    applied_at text NOT NULL,
    file_hash text NOT NULL
);


--
-- Name: connections; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.connections (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    db text NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: descriptions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.descriptions (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    connection_name text NOT NULL COLLATE pg_catalog."C",
    table_name text NOT NULL COLLATE pg_catalog."C",
    column_name text NOT NULL COLLATE pg_catalog."C",
    description text NOT NULL,
    source text NOT NULL,
    updated_at text NOT NULL,
    updated_by text
);


--
-- Name: destinations; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.destinations (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.events (
    id bigint NOT NULL,
    type text NOT NULL COLLATE pg_catalog."C",
    source text COLLATE pg_catalog."C",
    occurred_at text NOT NULL,
    key_name text COLLATE pg_catalog."C",
    connection_name text COLLATE pg_catalog."C",
    query_name text COLLATE pg_catalog."C",
    status text,
    payload_json text NOT NULL,
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.events_id_seq OWNED BY qag_fixture.events.id;


--
-- Name: execution_history; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.execution_history (
    rowid bigint NOT NULL,
    query_name text COLLATE pg_catalog."C",
    version integer,
    executed_at text NOT NULL,
    entry_json text NOT NULL,
    status text,
    key_name text,
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.execution_history_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.execution_history_rowid_seq OWNED BY qag_fixture.execution_history.rowid;


--
-- Name: exports; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.exports (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    watermark text,
    lease_until double precision,
    details_json text NOT NULL
);


--
-- Name: instances; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.instances (
    id text NOT NULL COLLATE pg_catalog."C",
    host text NOT NULL,
    pid integer NOT NULL,
    role text NOT NULL,
    version text NOT NULL,
    shared_limits integer NOT NULL,
    started_at double precision NOT NULL,
    last_seen double precision NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.roles (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: saved_queries; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_queries (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    collection text COLLATE pg_catalog."C",
    example integer DEFAULT 0 NOT NULL,
    published_version integer
);


--
-- Name: saved_query_versions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_query_versions (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    query_name text NOT NULL COLLATE pg_catalog."C",
    version integer NOT NULL,
    uuid text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text NOT NULL,
    last_modified_at text NOT NULL,
    fields_json text NOT NULL
);


--
-- Name: schema_version; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.schema_version (
    version integer NOT NULL
);


--
-- Name: server_secrets; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.server_secrets (
    name text NOT NULL COLLATE pg_catalog."C",
    value text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: sso_logins; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.sso_logins (
    state_hash text NOT NULL COLLATE pg_catalog."C",
    browser_hash text NOT NULL,
    nonce text NOT NULL,
    verifier text NOT NULL,
    return_to text NOT NULL,
    created_at double precision NOT NULL
);


--
-- Name: usage_counters; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.usage_counters (
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C",
    caller text NOT NULL COLLATE pg_catalog."C",
    period text NOT NULL COLLATE pg_catalog."C",
    calls bigint DEFAULT 0 NOT NULL,
    rows bigint DEFAULT 0 NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: workspace_members; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.workspace_members (
    workspace text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.workspaces (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: write_requests; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.write_requests (
    id text NOT NULL COLLATE pg_catalog."C",
    query_name text NOT NULL,
    version integer NOT NULL,
    caller text NOT NULL,
    status text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    idempotency_hash text,
    details_json text NOT NULL,
    workspace text DEFAULT 'default'::text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log ALTER COLUMN id SET DEFAULT nextval('qag_fixture.audit_log_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.events ALTER COLUMN id SET DEFAULT nextval('qag_fixture.events_id_seq'::regclass);


--
-- Name: execution_history rowid; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history ALTER COLUMN rowid SET DEFAULT nextval('qag_fixture.execution_history_rowid_seq'::regclass);


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: admin_tokens; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: administrators; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.api_keys VALUES ('default', 'reporting', '98f6997755c62a59a0d4910583e091c32a6cf86c8d5efe967592fd7a23c85f7a', 1, NULL, '2026-10-17 13:27:02', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null}', NULL, NULL);


--
-- Data for Name: audit_chain; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_delivery; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.audit_log VALUES (1, DEFAULT, '2026-10-17 13:27:02', '{"timestamp": "2026-10-17 13:27:02", "actor": "admin", "via": "break-glass", "action": "create_connection", "target": "films", "changes": {"database": "/tmp/qag-fixture-0.39.0-7jsrd1wu/data.db", "db": "sqlite", "active": true, "created_at": "2026-10-17 13:27:02", "updated_at": "2026-10-17 13:27:02"}, "workspace": "default"}', 1, '0000000000000000000000000000000000000000000000000000000000000000', 'sha256:98a828336801b76feed83936a7b7b12c3fe40e44ee3daaf7a15332d23bba7ad4');
INSERT INTO qag_fixture.audit_log VALUES (2, DEFAULT, '2026-10-17 13:27:02', '{"timestamp": "2026-10-17 13:27:02", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 1, "connection_name": "films", "published": true}, "workspace": "default"}', 2, 'sha256:98a828336801b76feed83936a7b7b12c3fe40e44ee3daaf7a15332d23bba7ad4', 'sha256:2136b445562880d3865ba9a58736f53b448c1bfc0237ffec3151c865a4e08ea8');
INSERT INTO qag_fixture.audit_log VALUES (3, DEFAULT, '2026-10-17 13:27:02', '{"timestamp": "2026-10-17 13:27:02", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 2, "connection_name": "films", "published": true}, "workspace": "default"}', 3, 'sha256:2136b445562880d3865ba9a58736f53b448c1bfc0237ffec3151c865a4e08ea8', 'sha256:5807e2ae6db3460a223a7cb8a26d6cf16f5ecc30af104c05ff5994f271b52c68');
INSERT INTO qag_fixture.audit_log VALUES (4, DEFAULT, '2026-10-17 13:27:02', '{"timestamp": "2026-10-17 13:27:02", "actor": "admin", "via": "break-glass", "action": "create_key", "target": "reporting", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null, "active": true, "expires_at": null, "created_at": "2026-10-17 13:27:02", "previous_expires_at": null}, "workspace": "default"}', 4, 'sha256:5807e2ae6db3460a223a7cb8a26d6cf16f5ecc30af104c05ff5994f271b52c68', 'sha256:5fc4900ed45c54f50cbf3da035d8e5384a252a8e964de562d4901f9712875287');
INSERT INTO qag_fixture.audit_log VALUES (5, DEFAULT, '2026-10-17 13:27:02', '{"timestamp": "2026-10-17 13:27:02", "actor": "admin", "via": "break-glass", "action": "create_role", "target": "analyst", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_at": "2026-10-17 13:27:02"}, "workspace": "default"}', 5, 'sha256:5fc4900ed45c54f50cbf3da035d8e5384a252a8e964de562d4901f9712875287', 'sha256:61e0ad4574ca007e84cd850bb8792619f7bae82e54a5b22de97ac884506881ab');


--
-- Data for Name: config_applied; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: config_managed; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: connections; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.connections VALUES ('default', 'films', 'sqlite', 1, '2026-10-17 13:27:02', '2026-10-17 13:27:02', '{"database": "/tmp/qag-fixture-0.39.0-7jsrd1wu/data.db"}');


--
-- Data for Name: descriptions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: destinations; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: events; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.events VALUES (1, 'query.run', 'rest', '2026-10-17 13:27:02', 'admin', 'films', 'films_by_rating', 'success', '{"type": "query.run", "source": "rest", "occurred_at": "2026-10-17 13:27:02", "kind": "saved", "query": "films_by_rating", "version": 2, "connection_name": "films", "entry": {"executed_at": "2026-10-17 13:27:02", "connection_name": "films", "request_id": "f9837eb3537d", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 3, "serialization_ms": 0.1}}', 'default');


--
-- Data for Name: execution_history; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.execution_history VALUES (1, 'films_by_rating', 2, '2026-10-17 13:27:02', '{"executed_at": "2026-10-17 13:27:02", "connection_name": "films", "request_id": "f9837eb3537d", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 3, "serialization_ms": 0.1}', 'success', 'admin', 'default');


--
-- Data for Name: exports; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: instances; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.instances VALUES ('562e8d8bdead-211638', 'anantharajuc-ThinkPad-P15v-Gen-3', 211638, 'serve', '0.39.0', 0, 1792223822.3650887, 1792223822.3650887);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.roles VALUES ('default', 'analyst', '2026-10-17 13:27:02', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null}');


--
-- Data for Name: saved_queries; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_queries VALUES ('default', 'films_by_rating', NULL, 0, 2);


--
-- Data for Name: saved_query_versions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_query_versions VALUES ('default', 'films_by_rating', 1, 'af497e82-9fe8-4284-b11c-814177be846e', 'active', '2026-10-17 13:27:02', '2026-10-17 13:27:02', '{"author": "fixture", "description": "Films by rating", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating"}');
INSERT INTO qag_fixture.saved_query_versions VALUES ('default', 'films_by_rating', 2, '0ca5750d-4a98-4f93-9c1b-47ae852392d5', 'active', '2026-10-17 13:27:02', '2026-10-17 13:27:02', '{"author": "fixture", "description": "Films by rating, sorted", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating ORDER BY title"}');


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.schema_version VALUES (17);


--
-- Data for Name: server_secrets; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: sso_logins; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: workspace_members; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.workspaces VALUES ('default', '2026-10-17 13:27:02', '{"description": "Everything this server had before workspaces, and what is made without naming one"}');


--
-- Data for Name: write_requests; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.audit_log_id_seq', 5, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.events_id_seq', 1, true);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.execution_history_rowid_seq', 1, true);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id_hash);


--
-- Name: admin_tokens admin_tokens_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_hash_key UNIQUE (hash);


--
-- Name: admin_tokens admin_tokens_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_pkey PRIMARY KEY (id);


--
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (name);


--
-- Name: api_keys api_keys_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_hash_key UNIQUE (hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (workspace, name);


--
-- Name: audit_chain audit_chain_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_chain
    ADD CONSTRAINT audit_chain_pkey PRIMARY KEY (name);


--
-- Name: audit_delivery audit_delivery_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_delivery
    ADD CONSTRAINT audit_delivery_pkey PRIMARY KEY (output);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: config_applied config_applied_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.config_applied
    ADD CONSTRAINT config_applied_pkey PRIMARY KEY (file_hash);


--
-- Name: config_managed config_managed_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.config_managed
    ADD CONSTRAINT config_managed_pkey PRIMARY KEY (workspace, kind, name);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (workspace, name);


--
-- Name: descriptions descriptions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.descriptions
    ADD CONSTRAINT descriptions_pkey PRIMARY KEY (workspace, connection_name, table_name, column_name);


--
-- Name: destinations destinations_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.destinations
    ADD CONSTRAINT destinations_pkey PRIMARY KEY (workspace, name);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: execution_history execution_history_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_pkey PRIMARY KEY (rowid);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (workspace, name);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (workspace, name);


--
-- Name: saved_queries saved_queries_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_queries
    ADD CONSTRAINT saved_queries_pkey PRIMARY KEY (workspace, name);


--
-- Name: saved_query_versions saved_query_versions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_pkey PRIMARY KEY (workspace, query_name, version);


--
-- Name: server_secrets server_secrets_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.server_secrets
    ADD CONSTRAINT server_secrets_pkey PRIMARY KEY (name);


--
-- Name: sso_logins sso_logins_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.sso_logins
    ADD CONSTRAINT sso_logins_pkey PRIMARY KEY (state_hash);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (workspace, caller, period);


--
-- Name: workspace_members workspace_members_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.workspace_members
    ADD CONSTRAINT workspace_members_pkey PRIMARY KEY (workspace, admin_name);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (name);


--
-- Name: write_requests write_requests_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.write_requests
    ADD CONSTRAINT write_requests_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_sessions_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_sessions_admin ON qag_fixture.admin_sessions USING btree (admin_name);


--
-- Name: idx_admin_tokens_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_tokens_admin ON qag_fixture.admin_tokens USING btree (admin_name);


--
-- Name: idx_api_keys_previous_hash; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_api_keys_previous_hash ON qag_fixture.api_keys USING btree (previous_hash);


--
-- Name: idx_audit_log_seq; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE UNIQUE INDEX idx_audit_log_seq ON qag_fixture.audit_log USING btree (seq);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_audit_log_timestamp ON qag_fixture.audit_log USING btree ("timestamp");


--
-- Name: idx_events_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_events_time ON qag_fixture.events USING btree (occurred_at);


--
-- Name: idx_events_ws; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_events_ws ON qag_fixture.events USING btree (workspace, id);


--
-- Name: idx_execution_history_qv; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_qv ON qag_fixture.execution_history USING btree (query_name, version, executed_at);


--
-- Name: idx_execution_history_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_time ON qag_fixture.execution_history USING btree (executed_at);


--
-- Name: idx_execution_history_ws; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_ws ON qag_fixture.execution_history USING btree (workspace, executed_at);


--
-- Name: idx_workspace_members_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_workspace_members_admin ON qag_fixture.workspace_members USING btree (admin_name);


--
-- Name: idx_write_requests_idempotency; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_idempotency ON qag_fixture.write_requests USING btree (idempotency_hash);


--
-- Name: idx_write_requests_status; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_status ON qag_fixture.write_requests USING btree (status);


--
-- Name: execution_history execution_history_workspace_query_name_version_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_workspace_query_name_version_fkey FOREIGN KEY (workspace, query_name, version) REFERENCES qag_fixture.saved_query_versions(workspace, query_name, version) ON DELETE CASCADE;


--
-- Name: saved_query_versions saved_query_versions_workspace_query_name_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_workspace_query_name_fkey FOREIGN KEY (workspace, query_name) REFERENCES qag_fixture.saved_queries(workspace, name) ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_workspace_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.workspace_members
    ADD CONSTRAINT workspace_members_workspace_fkey FOREIGN KEY (workspace) REFERENCES qag_fixture.workspaces(name) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict lsQ84PVIVgougVsdx8PslV3VHijR84a3closVKKfG9cmLavXj1zN65Szp9XTo7d

