--
-- PostgreSQL database dump
--

\restrict IfxIoucScZJR9zLsOqcaObvvcfQyll41XdlKEmq2CrAAGwsgJt1OZhlHqSWTacn

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: qag_fixture; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA qag_fixture;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_sessions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_sessions (
    id_hash text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    csrf text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    details_json text NOT NULL
);


--
-- Name: admin_tokens; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_tokens (
    id text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    hash text NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: administrators; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.administrators (
    name text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.api_keys (
    name text NOT NULL COLLATE pg_catalog."C",
    hash text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL,
    previous_hash text,
    previous_expires_at text
);


--
-- Name: audit_chain; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_chain (
    name text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    hash text NOT NULL
);


--
-- Name: audit_delivery; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_delivery (
    output text NOT NULL COLLATE pg_catalog."C",
    last_seq bigint DEFAULT 0 NOT NULL,
    lease_until double precision,
    details_json text DEFAULT '{}'::text NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_log (
    id bigint NOT NULL,
    rowid bigint GENERATED ALWAYS AS (id) STORED,
    "timestamp" text NOT NULL,
    entry_json text NOT NULL,
    seq bigint,
    prev_hash text,
    hash text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.audit_log_id_seq OWNED BY qag_fixture.audit_log.id;


--
-- Name: connections; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.connections (
    name text NOT NULL COLLATE pg_catalog."C",
    db text NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: descriptions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.descriptions (
    connection_name text NOT NULL COLLATE pg_catalog."C",
    table_name text NOT NULL COLLATE pg_catalog."C",
    column_name text NOT NULL COLLATE pg_catalog."C",
    description text NOT NULL,
    source text NOT NULL,
    updated_at text NOT NULL,
    updated_by text
);


--
-- Name: destinations; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.destinations (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: execution_history; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.execution_history (
    rowid bigint NOT NULL,
    query_name text COLLATE pg_catalog."C",
    version integer,
    executed_at text NOT NULL,
    entry_json text NOT NULL,
    status text,
    key_name text
);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.execution_history_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.execution_history_rowid_seq OWNED BY qag_fixture.execution_history.rowid;


--
-- Name: exports; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.exports (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    watermark text,
    lease_until double precision,
    details_json text NOT NULL
);


--
-- Name: instances; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.instances (
    id text NOT NULL COLLATE pg_catalog."C",
    host text NOT NULL,
    pid integer NOT NULL,
    role text NOT NULL,
    version text NOT NULL,
    shared_limits integer NOT NULL,
    started_at double precision NOT NULL,
    last_seen double precision NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.roles (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: saved_queries; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_queries (
    name text NOT NULL COLLATE pg_catalog."C",
    collection text COLLATE pg_catalog."C",
    example integer DEFAULT 0 NOT NULL,
    published_version integer
);


--
-- Name: saved_query_versions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_query_versions (
    query_name text NOT NULL COLLATE pg_catalog."C",
    version integer NOT NULL,
    uuid text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text NOT NULL,
    last_modified_at text NOT NULL,
    fields_json text NOT NULL
);


--
-- Name: schema_version; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.schema_version (
    version integer NOT NULL
);


--
-- Name: server_secrets; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.server_secrets (
    name text NOT NULL COLLATE pg_catalog."C",
    value text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: sso_logins; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.sso_logins (
    state_hash text NOT NULL COLLATE pg_catalog."C",
    browser_hash text NOT NULL,
    nonce text NOT NULL,
    verifier text NOT NULL,
    return_to text NOT NULL,
    created_at double precision NOT NULL
);


--
-- Name: usage_counters; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.usage_counters (
    caller text NOT NULL COLLATE pg_catalog."C",
    period text NOT NULL COLLATE pg_catalog."C",
    calls bigint DEFAULT 0 NOT NULL,
    rows bigint DEFAULT 0 NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: write_requests; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.write_requests (
    id text NOT NULL COLLATE pg_catalog."C",
    query_name text NOT NULL,
    version integer NOT NULL,
    caller text NOT NULL,
    status text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    idempotency_hash text,
    details_json text NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log ALTER COLUMN id SET DEFAULT nextval('qag_fixture.audit_log_id_seq'::regclass);


--
-- Name: execution_history rowid; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history ALTER COLUMN rowid SET DEFAULT nextval('qag_fixture.execution_history_rowid_seq'::regclass);


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: admin_tokens; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: administrators; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.api_keys VALUES ('reporting', '25f2eb8f2f5fce0dcbb8486b749e7f38bef4ca906f73991eb14b36539516d73d', 1, NULL, '2026-10-12 11:10:08', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null}', NULL, NULL);


--
-- Data for Name: audit_chain; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_delivery; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.audit_log VALUES (1, DEFAULT, '2026-10-12 11:10:08', '{"timestamp": "2026-10-12 11:10:08", "actor": "admin", "via": "break-glass", "action": "create_connection", "target": "films", "changes": {"database": "/tmp/qag-fixture-0.25.0-_mta3tvi/data.db", "db": "sqlite", "active": true, "created_at": "2026-10-12 11:10:08", "updated_at": "2026-10-12 11:10:08"}}', 1, '0000000000000000000000000000000000000000000000000000000000000000', 'sha256:d487f9517ff5385915b1711e30a4ac5a8088f67ef34866e287d6f1ea4686da8d');
INSERT INTO qag_fixture.audit_log VALUES (2, DEFAULT, '2026-10-12 11:10:08', '{"timestamp": "2026-10-12 11:10:08", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 1, "connection_name": "films", "published": true}}', 2, 'sha256:d487f9517ff5385915b1711e30a4ac5a8088f67ef34866e287d6f1ea4686da8d', 'sha256:efd97330638632c7fc2a18bec66febccf3360d8cab7be59242d8d27925247883');
INSERT INTO qag_fixture.audit_log VALUES (3, DEFAULT, '2026-10-12 11:10:08', '{"timestamp": "2026-10-12 11:10:08", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 2, "connection_name": "films", "published": true}}', 3, 'sha256:efd97330638632c7fc2a18bec66febccf3360d8cab7be59242d8d27925247883', 'sha256:0a18344479cfac65fa08c2d88835a3c323c0f4a1ce8bbc4b1cf49a18b5135971');
INSERT INTO qag_fixture.audit_log VALUES (4, DEFAULT, '2026-10-12 11:10:08', '{"timestamp": "2026-10-12 11:10:08", "actor": "admin", "via": "break-glass", "action": "create_key", "target": "reporting", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null, "active": true, "expires_at": null, "created_at": "2026-10-12 11:10:08", "previous_expires_at": null}}', 4, 'sha256:0a18344479cfac65fa08c2d88835a3c323c0f4a1ce8bbc4b1cf49a18b5135971', 'sha256:2d42031319ddebb43db2d0e162b53a1a74f1dea35a050a2cea64a896ef781ba0');
INSERT INTO qag_fixture.audit_log VALUES (5, DEFAULT, '2026-10-12 11:10:08', '{"timestamp": "2026-10-12 11:10:08", "actor": "admin", "via": "break-glass", "action": "create_role", "target": "analyst", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_at": "2026-10-12 11:10:08"}}', 5, 'sha256:2d42031319ddebb43db2d0e162b53a1a74f1dea35a050a2cea64a896ef781ba0', 'sha256:50389ff2917757bff4d4aa1dad719e9e52f7b927d416900dcf5882a38d3552fa');


--
-- Data for Name: connections; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.connections VALUES ('films', 'sqlite', 1, '2026-10-12 11:10:08', '2026-10-12 11:10:08', '{"database": "/tmp/qag-fixture-0.25.0-_mta3tvi/data.db"}');


--
-- Data for Name: descriptions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: destinations; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: execution_history; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.execution_history VALUES (1, 'films_by_rating', 2, '2026-10-12 11:10:08', '{"executed_at": "2026-10-12 11:10:08", "connection_name": "films", "request_id": "5a981230af74", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 4, "serialization_ms": 0.2}', 'success', 'admin');


--
-- Data for Name: exports; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: instances; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.instances VALUES ('9a2b92d3270c-642333', 'anantharajuc-ThinkPad-P15v-Gen-3', 642333, 'serve', '0.25.0', 0, 1791783608.625428, 1791783608.625428);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.roles VALUES ('analyst', '2026-10-12 11:10:08', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null}');


--
-- Data for Name: saved_queries; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_queries VALUES ('films_by_rating', NULL, 0, 2);


--
-- Data for Name: saved_query_versions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 1, '5ed332b6-8c29-43cb-9bd6-34a7c9a96a69', 'active', '2026-10-12 11:10:08', '2026-10-12 11:10:08', '{"author": "fixture", "description": "Films by rating", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating"}');
INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 2, '7980a7f6-61d8-487c-ad38-12ec55078890', 'active', '2026-10-12 11:10:08', '2026-10-12 11:10:08', '{"author": "fixture", "description": "Films by rating, sorted", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating ORDER BY title"}');


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.schema_version VALUES (14);


--
-- Data for Name: server_secrets; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: sso_logins; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: write_requests; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.audit_log_id_seq', 5, true);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.execution_history_rowid_seq', 1, true);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id_hash);


--
-- Name: admin_tokens admin_tokens_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_hash_key UNIQUE (hash);


--
-- Name: admin_tokens admin_tokens_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_pkey PRIMARY KEY (id);


--
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (name);


--
-- Name: api_keys api_keys_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_hash_key UNIQUE (hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (name);


--
-- Name: audit_chain audit_chain_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_chain
    ADD CONSTRAINT audit_chain_pkey PRIMARY KEY (name);


--
-- Name: audit_delivery audit_delivery_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_delivery
    ADD CONSTRAINT audit_delivery_pkey PRIMARY KEY (output);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (name);


--
-- Name: descriptions descriptions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.descriptions
    ADD CONSTRAINT descriptions_pkey PRIMARY KEY (connection_name, table_name, column_name);


--
-- Name: destinations destinations_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.destinations
    ADD CONSTRAINT destinations_pkey PRIMARY KEY (name);


--
-- Name: execution_history execution_history_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_pkey PRIMARY KEY (rowid);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (name);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (name);


--
-- Name: saved_queries saved_queries_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_queries
    ADD CONSTRAINT saved_queries_pkey PRIMARY KEY (name);


--
-- Name: saved_query_versions saved_query_versions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_pkey PRIMARY KEY (query_name, version);


--
-- Name: server_secrets server_secrets_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.server_secrets
    ADD CONSTRAINT server_secrets_pkey PRIMARY KEY (name);


--
-- Name: sso_logins sso_logins_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.sso_logins
    ADD CONSTRAINT sso_logins_pkey PRIMARY KEY (state_hash);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (caller, period);


--
-- Name: write_requests write_requests_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.write_requests
    ADD CONSTRAINT write_requests_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_sessions_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_sessions_admin ON qag_fixture.admin_sessions USING btree (admin_name);


--
-- Name: idx_admin_tokens_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_tokens_admin ON qag_fixture.admin_tokens USING btree (admin_name);


--
-- Name: idx_api_keys_previous_hash; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_api_keys_previous_hash ON qag_fixture.api_keys USING btree (previous_hash);


--
-- Name: idx_audit_log_seq; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE UNIQUE INDEX idx_audit_log_seq ON qag_fixture.audit_log USING btree (seq);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_audit_log_timestamp ON qag_fixture.audit_log USING btree ("timestamp");


--
-- Name: idx_execution_history_qv; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_qv ON qag_fixture.execution_history USING btree (query_name, version, executed_at);


--
-- Name: idx_execution_history_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_time ON qag_fixture.execution_history USING btree (executed_at);


--
-- Name: idx_write_requests_idempotency; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_idempotency ON qag_fixture.write_requests USING btree (idempotency_hash);


--
-- Name: idx_write_requests_status; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_status ON qag_fixture.write_requests USING btree (status);


--
-- Name: execution_history execution_history_query_name_version_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_query_name_version_fkey FOREIGN KEY (query_name, version) REFERENCES qag_fixture.saved_query_versions(query_name, version) ON DELETE CASCADE;


--
-- Name: saved_query_versions saved_query_versions_query_name_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_query_name_fkey FOREIGN KEY (query_name) REFERENCES qag_fixture.saved_queries(name) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict IfxIoucScZJR9zLsOqcaObvvcfQyll41XdlKEmq2CrAAGwsgJt1OZhlHqSWTacn

