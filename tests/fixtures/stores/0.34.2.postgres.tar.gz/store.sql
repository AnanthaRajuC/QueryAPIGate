--
-- PostgreSQL database dump
--

\restrict cXnXwQh7kD6PFQY4YYTNas2GT8qlvavd7uOqbk6fe8tZU80quNaTEH80KRv9VUb

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: qag_fixture; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA qag_fixture;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_sessions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_sessions (
    id_hash text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    csrf text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    details_json text NOT NULL
);


--
-- Name: admin_tokens; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.admin_tokens (
    id text NOT NULL COLLATE pg_catalog."C",
    admin_name text NOT NULL,
    hash text NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: administrators; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.administrators (
    name text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.api_keys (
    name text NOT NULL COLLATE pg_catalog."C",
    hash text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    details_json text NOT NULL,
    previous_hash text,
    previous_expires_at text
);


--
-- Name: audit_chain; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_chain (
    name text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    hash text NOT NULL
);


--
-- Name: audit_delivery; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_delivery (
    output text NOT NULL COLLATE pg_catalog."C",
    last_seq bigint DEFAULT 0 NOT NULL,
    lease_until double precision,
    details_json text DEFAULT '{}'::text NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.audit_log (
    id bigint NOT NULL,
    rowid bigint GENERATED ALWAYS AS (id) STORED,
    "timestamp" text NOT NULL,
    entry_json text NOT NULL,
    seq bigint,
    prev_hash text,
    hash text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.audit_log_id_seq OWNED BY qag_fixture.audit_log.id;


--
-- Name: config_applied; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.config_applied (
    file_hash text NOT NULL COLLATE pg_catalog."C",
    applied_at text NOT NULL,
    actor text NOT NULL
);


--
-- Name: config_managed; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.config_managed (
    kind text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    applied_at text NOT NULL,
    file_hash text NOT NULL
);


--
-- Name: connections; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.connections (
    name text NOT NULL COLLATE pg_catalog."C",
    db text NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: descriptions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.descriptions (
    connection_name text NOT NULL COLLATE pg_catalog."C",
    table_name text NOT NULL COLLATE pg_catalog."C",
    column_name text NOT NULL COLLATE pg_catalog."C",
    description text NOT NULL,
    source text NOT NULL,
    updated_at text NOT NULL,
    updated_by text
);


--
-- Name: destinations; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.destinations (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.events (
    id bigint NOT NULL,
    type text NOT NULL COLLATE pg_catalog."C",
    source text COLLATE pg_catalog."C",
    occurred_at text NOT NULL,
    key_name text COLLATE pg_catalog."C",
    connection_name text COLLATE pg_catalog."C",
    query_name text COLLATE pg_catalog."C",
    status text,
    payload_json text NOT NULL
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.events_id_seq OWNED BY qag_fixture.events.id;


--
-- Name: execution_history; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.execution_history (
    rowid bigint NOT NULL,
    query_name text COLLATE pg_catalog."C",
    version integer,
    executed_at text NOT NULL,
    entry_json text NOT NULL,
    status text,
    key_name text
);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE; Schema: qag_fixture; Owner: -
--

CREATE SEQUENCE qag_fixture.execution_history_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE OWNED BY; Schema: qag_fixture; Owner: -
--

ALTER SEQUENCE qag_fixture.execution_history_rowid_seq OWNED BY qag_fixture.execution_history.rowid;


--
-- Name: exports; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.exports (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    updated_at text NOT NULL,
    watermark text,
    lease_until double precision,
    details_json text NOT NULL
);


--
-- Name: instances; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.instances (
    id text NOT NULL COLLATE pg_catalog."C",
    host text NOT NULL,
    pid integer NOT NULL,
    role text NOT NULL,
    version text NOT NULL,
    shared_limits integer NOT NULL,
    started_at double precision NOT NULL,
    last_seen double precision NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.roles (
    name text NOT NULL COLLATE pg_catalog."C",
    created_at text NOT NULL,
    details_json text NOT NULL
);


--
-- Name: saved_queries; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_queries (
    name text NOT NULL COLLATE pg_catalog."C",
    collection text COLLATE pg_catalog."C",
    example integer DEFAULT 0 NOT NULL,
    published_version integer
);


--
-- Name: saved_query_versions; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.saved_query_versions (
    query_name text NOT NULL COLLATE pg_catalog."C",
    version integer NOT NULL,
    uuid text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text NOT NULL,
    last_modified_at text NOT NULL,
    fields_json text NOT NULL
);


--
-- Name: schema_version; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.schema_version (
    version integer NOT NULL
);


--
-- Name: server_secrets; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.server_secrets (
    name text NOT NULL COLLATE pg_catalog."C",
    value text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: sso_logins; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.sso_logins (
    state_hash text NOT NULL COLLATE pg_catalog."C",
    browser_hash text NOT NULL,
    nonce text NOT NULL,
    verifier text NOT NULL,
    return_to text NOT NULL,
    created_at double precision NOT NULL
);


--
-- Name: usage_counters; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.usage_counters (
    caller text NOT NULL COLLATE pg_catalog."C",
    period text NOT NULL COLLATE pg_catalog."C",
    calls bigint DEFAULT 0 NOT NULL,
    rows bigint DEFAULT 0 NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: write_requests; Type: TABLE; Schema: qag_fixture; Owner: -
--

CREATE TABLE qag_fixture.write_requests (
    id text NOT NULL COLLATE pg_catalog."C",
    query_name text NOT NULL,
    version integer NOT NULL,
    caller text NOT NULL,
    status text NOT NULL,
    created_at text NOT NULL,
    expires_at double precision NOT NULL,
    idempotency_hash text,
    details_json text NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log ALTER COLUMN id SET DEFAULT nextval('qag_fixture.audit_log_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.events ALTER COLUMN id SET DEFAULT nextval('qag_fixture.events_id_seq'::regclass);


--
-- Name: execution_history rowid; Type: DEFAULT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history ALTER COLUMN rowid SET DEFAULT nextval('qag_fixture.execution_history_rowid_seq'::regclass);


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: admin_tokens; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: administrators; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.api_keys VALUES ('reporting', 'f35c94675235fa4f17e89ffe8fac5d4d53390667a3752818e74f3fd9f8d4b082', 1, NULL, '2026-10-14 20:09:59', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null}', NULL, NULL);


--
-- Data for Name: audit_chain; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_delivery; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.audit_log VALUES (1, DEFAULT, '2026-10-14 20:09:59', '{"timestamp": "2026-10-14 20:09:59", "actor": "admin", "via": "break-glass", "action": "create_connection", "target": "films", "changes": {"database": "/tmp/qag-fixture-0.34.2-r50s80k_/data.db", "db": "sqlite", "active": true, "created_at": "2026-10-14 20:09:59", "updated_at": "2026-10-14 20:09:59"}}', 1, '0000000000000000000000000000000000000000000000000000000000000000', 'sha256:e4e95a5af2faafa2f03bb027e8218245611e154ea1f8d2249def19f30eab85e9');
INSERT INTO qag_fixture.audit_log VALUES (2, DEFAULT, '2026-10-14 20:09:59', '{"timestamp": "2026-10-14 20:09:59", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 1, "connection_name": "films", "published": true}}', 2, 'sha256:e4e95a5af2faafa2f03bb027e8218245611e154ea1f8d2249def19f30eab85e9', 'sha256:4d65335ac78d8ae3ccd0a632910fcfb61f7bc8930cb601e4db744fee2e3115ae');
INSERT INTO qag_fixture.audit_log VALUES (3, DEFAULT, '2026-10-14 20:09:59', '{"timestamp": "2026-10-14 20:09:59", "actor": "admin", "via": "break-glass", "action": "save_query", "target": "films_by_rating", "changes": {"version": 2, "connection_name": "films", "published": true}}', 3, 'sha256:4d65335ac78d8ae3ccd0a632910fcfb61f7bc8930cb601e4db744fee2e3115ae', 'sha256:b43ef4c72ece2faf3444ef0a8ebed59b7f3359d91301a79f431fd9f373c104ff');
INSERT INTO qag_fixture.audit_log VALUES (4, DEFAULT, '2026-10-14 20:09:59', '{"timestamp": "2026-10-14 20:09:59", "actor": "admin", "via": "break-glass", "action": "create_key", "target": "reporting", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_from_role": null, "active": true, "expires_at": null, "created_at": "2026-10-14 20:09:59", "previous_expires_at": null}}', 4, 'sha256:b43ef4c72ece2faf3444ef0a8ebed59b7f3359d91301a79f431fd9f373c104ff', 'sha256:26507745170fcfc69d3d72dbb23b485964dc8137fc67af06950fba92cbec54f5');
INSERT INTO qag_fixture.audit_log VALUES (5, DEFAULT, '2026-10-14 20:09:59', '{"timestamp": "2026-10-14 20:09:59", "actor": "admin", "via": "break-glass", "action": "create_role", "target": "analyst", "changes": {"collections": [], "connections": ["films"], "allow_writes": false, "queries": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null, "created_at": "2026-10-14 20:09:59"}}', 5, 'sha256:26507745170fcfc69d3d72dbb23b485964dc8137fc67af06950fba92cbec54f5', 'sha256:d5312fdec71a2f4573f4897473b5f9ca29893a4acb9fba00a443d29d2a21095d');


--
-- Data for Name: config_applied; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: config_managed; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: connections; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.connections VALUES ('films', 'sqlite', 1, '2026-10-14 20:09:59', '2026-10-14 20:09:59', '{"database": "/tmp/qag-fixture-0.34.2-r50s80k_/data.db"}');


--
-- Data for Name: descriptions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: destinations; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: events; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.events VALUES (1, 'query.run', 'rest', '2026-10-14 20:09:59', 'admin', 'films', 'films_by_rating', 'success', '{"type": "query.run", "source": "rest", "occurred_at": "2026-10-14 20:09:59", "kind": "saved", "query": "films_by_rating", "version": 2, "connection_name": "films", "entry": {"executed_at": "2026-10-14 20:09:59", "connection_name": "films", "request_id": "b85e2c9fb3f2", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 3, "serialization_ms": 0.1}}');


--
-- Data for Name: execution_history; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.execution_history VALUES (1, 'films_by_rating', 2, '2026-10-14 20:09:59', '{"executed_at": "2026-10-14 20:09:59", "connection_name": "films", "request_id": "b85e2c9fb3f2", "key_name": "admin", "transport": "rest", "status": "success", "rows": 2, "duration_ms": 3, "serialization_ms": 0.1}', 'success', 'admin');


--
-- Data for Name: exports; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: instances; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.instances VALUES ('a2d8067675ed-117024', 'anantharajuc-ThinkPad-P15v-Gen-3', 117024, 'serve', '0.34.2', 0, 1791988799.429735, 1791988799.429735);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.roles VALUES ('analyst', '2026-10-14 20:09:59', '{"connections": ["films"], "allow_writes": false, "queries": [], "collections": [], "rate_limit": null, "allowed_ips": null, "allowed_write_ops": null, "allowed_tables": null, "mask": null, "max_concurrent": null, "query_timeout": null, "max_rows": null, "quota": null}');


--
-- Data for Name: saved_queries; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_queries VALUES ('films_by_rating', NULL, 0, 2);


--
-- Data for Name: saved_query_versions; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 1, '64b3535b-0144-4e0b-b67c-5f7839b0de95', 'active', '2026-10-14 20:09:59', '2026-10-14 20:09:59', '{"author": "fixture", "description": "Films by rating", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating"}');
INSERT INTO qag_fixture.saved_query_versions VALUES ('films_by_rating', 2, 'cb35d3a3-7c59-4ed9-852a-ee7963650363', 'active', '2026-10-14 20:09:59', '2026-10-14 20:09:59', '{"author": "fixture", "description": "Films by rating, sorted", "tags": [], "query_parameters": {"rating": {"type": "str", "required": true}}, "connection_name": "films", "sql_query": "SELECT title FROM film WHERE rating = :rating ORDER BY title"}');


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--

INSERT INTO qag_fixture.schema_version VALUES (16);


--
-- Data for Name: server_secrets; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: sso_logins; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Data for Name: write_requests; Type: TABLE DATA; Schema: qag_fixture; Owner: -
--



--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.audit_log_id_seq', 5, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.events_id_seq', 1, true);


--
-- Name: execution_history_rowid_seq; Type: SEQUENCE SET; Schema: qag_fixture; Owner: -
--

SELECT pg_catalog.setval('qag_fixture.execution_history_rowid_seq', 1, true);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id_hash);


--
-- Name: admin_tokens admin_tokens_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_hash_key UNIQUE (hash);


--
-- Name: admin_tokens admin_tokens_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.admin_tokens
    ADD CONSTRAINT admin_tokens_pkey PRIMARY KEY (id);


--
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (name);


--
-- Name: api_keys api_keys_hash_key; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_hash_key UNIQUE (hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (name);


--
-- Name: audit_chain audit_chain_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_chain
    ADD CONSTRAINT audit_chain_pkey PRIMARY KEY (name);


--
-- Name: audit_delivery audit_delivery_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_delivery
    ADD CONSTRAINT audit_delivery_pkey PRIMARY KEY (output);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: config_applied config_applied_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.config_applied
    ADD CONSTRAINT config_applied_pkey PRIMARY KEY (file_hash);


--
-- Name: config_managed config_managed_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.config_managed
    ADD CONSTRAINT config_managed_pkey PRIMARY KEY (kind, name);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (name);


--
-- Name: descriptions descriptions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.descriptions
    ADD CONSTRAINT descriptions_pkey PRIMARY KEY (connection_name, table_name, column_name);


--
-- Name: destinations destinations_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.destinations
    ADD CONSTRAINT destinations_pkey PRIMARY KEY (name);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: execution_history execution_history_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_pkey PRIMARY KEY (rowid);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (name);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (name);


--
-- Name: saved_queries saved_queries_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_queries
    ADD CONSTRAINT saved_queries_pkey PRIMARY KEY (name);


--
-- Name: saved_query_versions saved_query_versions_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_pkey PRIMARY KEY (query_name, version);


--
-- Name: server_secrets server_secrets_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.server_secrets
    ADD CONSTRAINT server_secrets_pkey PRIMARY KEY (name);


--
-- Name: sso_logins sso_logins_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.sso_logins
    ADD CONSTRAINT sso_logins_pkey PRIMARY KEY (state_hash);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (caller, period);


--
-- Name: write_requests write_requests_pkey; Type: CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.write_requests
    ADD CONSTRAINT write_requests_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_sessions_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_sessions_admin ON qag_fixture.admin_sessions USING btree (admin_name);


--
-- Name: idx_admin_tokens_admin; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_admin_tokens_admin ON qag_fixture.admin_tokens USING btree (admin_name);


--
-- Name: idx_api_keys_previous_hash; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_api_keys_previous_hash ON qag_fixture.api_keys USING btree (previous_hash);


--
-- Name: idx_audit_log_seq; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE UNIQUE INDEX idx_audit_log_seq ON qag_fixture.audit_log USING btree (seq);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_audit_log_timestamp ON qag_fixture.audit_log USING btree ("timestamp");


--
-- Name: idx_events_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_events_time ON qag_fixture.events USING btree (occurred_at);


--
-- Name: idx_execution_history_qv; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_qv ON qag_fixture.execution_history USING btree (query_name, version, executed_at);


--
-- Name: idx_execution_history_time; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_execution_history_time ON qag_fixture.execution_history USING btree (executed_at);


--
-- Name: idx_write_requests_idempotency; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_idempotency ON qag_fixture.write_requests USING btree (idempotency_hash);


--
-- Name: idx_write_requests_status; Type: INDEX; Schema: qag_fixture; Owner: -
--

CREATE INDEX idx_write_requests_status ON qag_fixture.write_requests USING btree (status);


--
-- Name: execution_history execution_history_query_name_version_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.execution_history
    ADD CONSTRAINT execution_history_query_name_version_fkey FOREIGN KEY (query_name, version) REFERENCES qag_fixture.saved_query_versions(query_name, version) ON DELETE CASCADE;


--
-- Name: saved_query_versions saved_query_versions_query_name_fkey; Type: FK CONSTRAINT; Schema: qag_fixture; Owner: -
--

ALTER TABLE ONLY qag_fixture.saved_query_versions
    ADD CONSTRAINT saved_query_versions_query_name_fkey FOREIGN KEY (query_name) REFERENCES qag_fixture.saved_queries(name) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict cXnXwQh7kD6PFQY4YYTNas2GT8qlvavd7uOqbk6fe8tZU80quNaTEH80KRv9VUb

